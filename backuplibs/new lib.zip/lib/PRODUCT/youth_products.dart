import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:neumorphic_button/neumorphic_button.dart';

class YouthProducts extends StatefulWidget {
  const YouthProducts({Key? key}) : super(key: key);

  @override
  State<YouthProducts> createState() => _YouthProductsState();
}

class _YouthProductsState extends State<YouthProducts> {
  List<dynamic> kidsProducts = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchKidsProducts();
  }

  Future<void> fetchKidsProducts() async {
    const String url = 'http://13.60.166.65/display_product.php';
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status_code'] == 200) {
          setState(() {
            kidsProducts = data['products']
                .where((product) => product['usercategory'] == 'youth products')
                .toList();
            isLoading = false;
          });
        } else {
          _showErrorDialog(message: 'Error: ${data['msg']}');
        }
      } else {
        _showErrorDialog(
            message:
            'Failed to fetch products. Status code: ${response.statusCode}');
      }
    } catch (e) {
      _showErrorDialog(message: 'PLEASE CHECK YOUR INTERNET CONNECTION');
    }
  }

  void _showErrorDialog({String message = "An error occurred. Please try again."}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Error"),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Youth Products", style: TextStyle(fontFamily: "font", fontWeight: FontWeight.bold)),

      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 5.5 / 6,
        ),
        itemCount: kidsProducts.length,
        itemBuilder: (context, index) {
          final product = kidsProducts[index];
          return Card(
            color: Colors.white,
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
                      image: product['image'] != null && product['image'].isNotEmpty
                          ? DecorationImage(
                        image: NetworkImage(product['image']),
                        fit: BoxFit.cover,
                      )
                          : null,
                    ),
                    child: product['image'] == null || product['image'].isEmpty
                        ? const Icon(Icons.image_not_supported, color: Colors.grey, size: 50)
                        : null,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        product['product_name'],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          fontFamily: "font",
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      Text('Price: ₹${product['price']}', style: const TextStyle(fontSize: 14, color: Colors.green)),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 5, right: 5),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: NeumorphicButton(
                      onTap: () {},
                      bottomRightShadowBlurRadius: 15,
                      bottomRightShadowSpreadRadius: 1,
                      backgroundColor: const Color(0xFF223043),
                      topLeftShadowBlurRadius: 15,
                      topLeftShadowSpreadRadius: 1,
                      topLeftShadowColor: Colors.white,
                      bottomRightShadowColor: Colors.grey.shade500,
                      height: 30,
                      width: 70,
                      padding: EdgeInsets.zero,
                      child: const Center(
                        child: Text(
                          'Buy',
                          style: TextStyle(color: Colors.white, fontFamily: "font"),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
