import 'package:epi/WISHLIST/wishlist.dart';
import 'package:flutter/material.dart';
import '100wishlist.dart';
class wishlisttab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text("Favorite"),
          centerTitle: true,
          bottom: TabBar(
            indicator: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.purple, Colors.blueAccent],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            tabs: [
              Tab(icon: Icon(Icons.favorite, size: 28), text: "product wishlist"),
              Tab(icon: Icon(Icons.favorite, size: 28), text: "combo wishlist"),
            ],
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.deepPurple, Colors.black],
            ),
          ),
          child: TabBarView(
            children: [
              WishlistPage(),
              HundredWishlistPage(),
            ],
          ),
        ),
      ),
    );
  }
}
