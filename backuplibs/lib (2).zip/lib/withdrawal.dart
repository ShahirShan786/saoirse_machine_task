import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:neumorphic_button/neumorphic_button.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class Withdrawal extends StatefulWidget {
  final String amount;
  Withdrawal({super.key, required this.amount});

  @override
  State<Withdrawal> createState() => _WithdrawalState();
}

class _WithdrawalState extends State<Withdrawal> {
  TextEditingController withdrawalAmountController = TextEditingController();
  TextEditingController accountNoController = TextEditingController();
  TextEditingController bankNameController = TextEditingController();

  Future<void> submitWithdrawal() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('id'); // Get user ID from SharedPreferences

    if (userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("User ID not found. Please log in again."))
      );
      return;
    }

    String withdrawalAmount = withdrawalAmountController.text.trim();
    String accountNo = accountNoController.text.trim();
    String bankName = bankNameController.text.trim();

    if (withdrawalAmount.isEmpty || accountNo.isEmpty || bankName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Please fill all fields."))
      );
      return;
    }

    final response = await http.post(
      Uri.parse('http://13.60.166.65/insert_withdrawal.php'),
      body: {
        'user_id': userId,
        'request_amount': withdrawalAmount,
        'account_no': accountNo,
        'bank_name': bankName,
      },
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message']))
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to submit withdrawal request."))
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Withdrawal',
          style: TextStyle(color: Colors.black, fontFamily: "font"),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFormField(
              enabled: false,
              decoration: InputDecoration(
                prefixText: '₹ ${widget.amount}',
                label: Text("TOTAL AMOUNT", style: TextStyle(color: Colors.grey)),
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: withdrawalAmountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                label: Text("WITHDRAWAL AMOUNT", style: TextStyle(color: Colors.grey)),
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: accountNoController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                label: Text("ACCOUNT NO", style: TextStyle(color: Colors.grey)),
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: bankNameController,
              decoration: const InputDecoration(
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey)),
                  label: Text(
                    "BANK NAME",
                    style: TextStyle(color: Colors.grey),
                  ),
                  floatingLabelBehavior: FloatingLabelBehavior.always),
            ),

            SizedBox(height: 40),
            NeumorphicButton(
              bottomRightShadowBlurRadius: 10,
                              bottomRightShadowSpreadRadius: 0,
                              backgroundColor: const Color(0xFF84B5C2),
                              topLeftShadowBlurRadius: 8,
                              topLeftShadowSpreadRadius: 0,
                              topLeftShadowColor: Colors.white,
                              bottomRightShadowColor: Colors.grey.shade500,
                              height: 50,
                              width: MediaQuery.of(context).size.width,
                              padding: EdgeInsets.zero,
                              margin:
                              const EdgeInsets.only(right: 5, bottom: 5),
                              bottomRightOffset: const Offset(4, 4),
                              topLeftOffset: const Offset(-4, -4),
              onTap: submitWithdrawal,
              // backgroundColor: const Color(0xFF84B5C2),
              child: Center(
                child: Text(
                  'REQUEST',
                  style: TextStyle(color: Colors.white, fontFamily: "font", fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
