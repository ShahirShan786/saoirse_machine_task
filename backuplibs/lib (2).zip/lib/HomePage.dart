import 'package:epi/HOME/HomePage.dart';
import 'package:epi/PRODUCT%20TAB/product_origin.dart';
import 'package:epi/payscheme.dart';
import 'package:epi/referalcode.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Profile.dart';
import 'logIn.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

int page = 0;

class _HomepageState extends State<Homepage> {
  dynamic userId;

  int currentindex = 0;

  Future<void> logout(BuildContext context) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('id'); // Clear the user ID
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const logIn()),
    );
  }

  Future<String?> _getUserId() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('id'); // Retrieve the user ID
  }

  // Fetch userId on initialization
  @override
  void initState() {
    super.initState();
    _initializeUserId();
  }

  Future<void> _initializeUserId() async {
    userId = await _getUserId();
    setState(() {}); // Rebuild widget once userId is fetched
  }

  List<Widget> screens() {
    return [
      NewHomepage1(), ProductOrigin(),
       SchemeAndPayment(userId: userId), // Pass userId here
      const ReferralCode(),
       const ProfilePage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
        height: 70,
        child: BottomNavigationBar(
          backgroundColor: Colors.white,
          unselectedItemColor: Colors.grey,
          unselectedLabelStyle: const TextStyle(color: Colors.grey),
          selectedItemColor: Color(0xFF223043),
          showUnselectedLabels: true,
          selectedFontSize: 12,
          currentIndex: currentindex,
          type: BottomNavigationBarType.fixed,
          // fixedColor: Colors.deepPurle,
          items: [
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/home.png",
                  scale: 20,
                  color: currentindex == 0 ? Colors.red : Colors.black,
                ),
                label: "Home"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/menu.png",
                  scale: 20,
                  color: currentindex == 1 ? Colors.red : Colors.black,
                ),
                label: "Products"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/copy.png",
                  scale: 20,
                  color: currentindex == 2 ? Colors.red : Colors.black,
                ),
                label: "Plans"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/connect.png",
                  scale: 20,
                  color: currentindex == 3 ? Colors.red : Colors.black,
                ),
                label: "Referral"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/user.png",
                  scale: 20,
                  color: currentindex == 4 ? Colors.red : Colors.black,
                ),
                label: "Profile"),
          ],
          onTap: (index) async {
            if (index == 1) {
              userId = await _getUserId();
            }
            setState(() {
              currentindex = index;
            });
          },
        ),
      ),
      // appBar: AppBar(
      //   surfaceTintColor: Colors.transparent,
      //   centerTitle: true,
      //   backgroundColor: Colors.white,
      //   title: const Text(
      //     "EPI",
      //     style: TextStyle(
      //       color: Colors.black,
      //       letterSpacing: 8,
      //       fontWeight: FontWeight.bold,
      //       fontFamily: "font",
      //     ),
      //   ),
      //   actions: [
      //     IconButton(
      //       onPressed: () {
      //         Navigator.push(
      //           context,
      //           MaterialPageRoute(builder: (context) => const HelpPage()),
      //         );
      //       },
      //       icon: const Icon(Icons.help, color: Colors.black),
      //     ),
      //     IconButton(
      //       onPressed: () {
      //         Navigator.push(
      //           context,
      //           MaterialPageRoute(builder: (context) => wishlisttab()),
      //         );
      //       },
      //       icon: const Icon(Icons.favorite, color: Colors.red),
      //     ),
      //   ],
      // ),
      body: SafeArea(child: screens()[currentindex]),
      // drawer: const DrawerMenu(),
    );
  }
}
