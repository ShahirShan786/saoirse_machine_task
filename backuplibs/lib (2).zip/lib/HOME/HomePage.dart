import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import '../epiccalc.dart';
import '../logIn.dart';
import 'AppBar.dart';
import 'carousal_slider.dart';

class NewHomepage1 extends StatefulWidget {
  const NewHomepage1({super.key});

  @override
  State<NewHomepage1> createState() => _NewHomepage1State();
}

class _NewHomepage1State extends State<NewHomepage1> {
  List<dynamic> products = [];
  List<dynamic> filteredProducts = [];
  Set<String> hundredwishlist = {};
  bool isLoading = true;
  TextEditingController searchController = TextEditingController();
  int? flippedIndex;

  @override
  void initState() {
    super.initState();
    fetchProducts();
    loadWishlist();
    searchController.addListener(_filterProducts);
  }

  Future<void> loadWishlist() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      hundredwishlist = (prefs.getStringList('hundredwishlist') ?? []).toSet();
    });
  }

  Future<void> toggleWishlist(String productId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      if (hundredwishlist.contains(productId)) {
        hundredwishlist.remove(productId);
      } else {
        hundredwishlist.add(productId);
      }
      prefs.setStringList('hundredwishlist', hundredwishlist.toList());
    });
  }

  Future<void> fetchProducts() async {
    const String url = 'http://13.60.166.65/display_100product.php';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status_code'] == 200) {
          setState(() {
            products = data['products'];
            filteredProducts = products;
            isLoading = false;
          });
        } else {
          _showErrorDialog(message: 'Error: ${data['msg']}');
        }
      } else {
        _showErrorDialog(
            message:
                'Failed to fetch products. Status code: ${response.statusCode}');
      }
    } catch (e) {
      _showErrorDialog(message: 'PLEASE CHECK YOUR INTERNET CONNECTION');
    }
  }

  void _filterProducts() {
    String query = searchController.text.toLowerCase();
    setState(() {
      filteredProducts = products.where((product) {
        final name = product['product_name'].toLowerCase();
        final description = product['description']?.toLowerCase() ?? '';
        return name.contains(query) || description.contains(query);
      }).toList();
    });
  }

  void _showErrorDialog(
      {String message = "An error occurred. Please try again."}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            "Error",
            style: TextStyle(fontFamily: "font"),
          ),
          content: Text(
            message,
            style: const TextStyle(fontFamily: "font"),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("OK"),
            ),
          ],
        );
      },
    );
  }

  int currentindex = 0;
  bool ontap = false;
  bool fav = false;
  List<Widget> list = [
    BottomSheet(
        onClosing: () {},
        builder: (BuildContext) {
          return Container();
        })
  ];

  Future<void> logout(BuildContext context) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('id'); // Clear the user ID
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const logIn()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body:  isLoading
          ? const Center(child: CircularProgressIndicator())
          :CustomScrollView(
        slivers: [
          appbar(),
          SliverToBoxAdapter(
            child: Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                caroual_slider(),
                SizedBox(
                  height: 20,
                ),
                Divider(
                  color: Colors.grey.shade200,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: const [
                      Text(
                        "Category",
                        style:
                            TextStyle(color: Colors.black, fontFamily: "font1"),
                      ),
                      // Text(
                      //   "See all",
                      //   style: TextStyle(fontSize: 12, color: Colors.grey),
                      // )
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                // Padding(
                //   padding: const EdgeInsets.symmetric(horizontal: 20.0),
                //   child: SingleChildScrollView(
                //     scrollDirection: Axis.horizontal,
                //     child: Row(
                //       spacing: 25,
                //       children: [
                //         Column(
                //           children: [
                //             Container(
                //               height: 60,
                //               width: 60,
                //               decoration: BoxDecoration(
                //                 borderRadius: BorderRadius.circular(100),
                //                 image: DecorationImage(
                //                   fit: BoxFit.fill,
                //                   image: AssetImage("assets/images/g.png"),
                //                 ),
                //               ),
                //             ),
                //             SizedBox(
                //               height: 10,
                //             ),
                //             Text(
                //               "Grocery",
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.black,
                //                   fontSize: 8),
                //             ),
                //           ],
                //         ),
                //         Column(
                //           children: [
                //             Container(
                //               height: 60,
                //               width: 60,
                //               decoration: BoxDecoration(
                //                 borderRadius: BorderRadius.circular(100),
                //                 image: DecorationImage(
                //                   fit: BoxFit.fill,
                //                   image: AssetImage("assets/images/pho.png"),
                //                 ),
                //               ),
                //             ),
                //             SizedBox(
                //               height: 10,
                //             ),
                //             Text(
                //               "Mobles",
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.black,
                //                   fontSize: 8),
                //             ),
                //           ],
                //         ),
                //         Column(
                //           children: [
                //             Container(
                //               height: 60,
                //               width: 60,
                //               decoration: BoxDecoration(
                //                 borderRadius: BorderRadius.circular(100),
                //                 image: DecorationImage(
                //                   fit: BoxFit.fill,
                //                   image: AssetImage("assets/images/f.png"),
                //                 ),
                //               ),
                //             ),
                //             SizedBox(
                //               height: 10,
                //             ),
                //             Text(
                //               "Fashion",
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.black,
                //                   fontSize: 8),
                //             ),
                //           ],
                //         ),
                //         Column(
                //           children: [
                //             Container(
                //               height: 60,
                //               width: 60,
                //               decoration: BoxDecoration(
                //                 borderRadius: BorderRadius.circular(100),
                //                 image: DecorationImage(
                //                   fit: BoxFit.fill,
                //                   image: AssetImage("assets/images/gad.jpg"),
                //                 ),
                //               ),
                //             ),
                //             SizedBox(
                //               height: 10,
                //             ),
                //             Text(
                //               "Gadgets",
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.black,
                //                   fontSize: 8),
                //             ),
                //           ],
                //         ),
                //         Column(
                //           children: [
                //             Container(
                //               height: 60,
                //               width: 60,
                //               decoration: BoxDecoration(
                //                 color: Colors.white,
                //                 borderRadius: BorderRadius.circular(100),
                //                 image: DecorationImage(
                //                   fit: BoxFit.cover,
                //                   image: AssetImage("assets/images/h.png"),
                //                 ),
                //               ),
                //             ),
                //             SizedBox(
                //               height: 10,
                //             ),
                //             Text(
                //               "Home & Furniture",
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.black,
                //                   fontSize: 8),
                //             ),
                //           ],
                //         ),
                //         Column(
                //           children: [
                //             Container(
                //               height: 60,
                //               width: 60,
                //               decoration: BoxDecoration(
                //                 borderRadius: BorderRadius.circular(100),
                //                 image: DecorationImage(
                //                   fit: BoxFit.fill,
                //                   image: AssetImage("assets/images/e.png"),
                //                 ),
                //               ),
                //             ),
                //             SizedBox(
                //               height: 10,
                //             ),
                //             Text(
                //               "Appliances",
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.black,
                //                   fontSize: 8),
                //             ),
                //           ],
                //         ),
                //         Column(
                //           children: [
                //             Container(
                //               height: 60,
                //               width: 60,
                //               decoration: BoxDecoration(
                //                 borderRadius: BorderRadius.circular(100),
                //                 image: DecorationImage(
                //                   fit: BoxFit.fill,
                //                   image: AssetImage("assets/images/e.png"),
                //                 ),
                //               ),
                //             ),
                //             SizedBox(
                //               height: 10,
                //             ),
                //             Text(
                //               "Appliances",
                //               style: TextStyle(
                //                   fontWeight: FontWeight.bold,
                //                   color: Colors.black,
                //                   fontSize: 8),
                //             ),
                //           ],
                //         ),
                //       ],
                //     ),
                //   ),
                // ),
                Divider(
                  color: Colors.grey.shade200,
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 20, 0, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "100 Combo Products",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        alignment: Alignment.center,
                        padding: EdgeInsets.all(5),
                        height: 370,
                        width: 370,
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey.shade200)),
                        child: Expanded(
                          child: GridView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(5, 5, 5, 5),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              crossAxisSpacing: 15,
                              mainAxisSpacing: 15,
                              childAspectRatio: 4 / 4,
                            ),
                            itemCount: filteredProducts.length > 4
                                ? 4
                                : filteredProducts.length,
                            // Show only 4 items
                            itemBuilder: (context, index) {
                              final product = filteredProducts[index];
                              // final productId = product['product_id'].toString();
                              return Expanded(
                                child: InkWell(onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => Epicalc(
                                        productId:
                                        product['product_id'],
                                        price: double.parse(
                                            product['price']
                                                .toString()),
                                        image: product['image']
                                            .toString(),
                                        name: product['product_name']
                                            .toString(),
                                      ),
                                    ),
                                  );
                                },
                                  child: SizedBox(
                                    width: double.infinity,
                                    child: product['image'] != null &&
                                            product['image'].isNotEmpty
                                        ? Image.network(
                                            product['image'],
                                            fit: BoxFit.cover,
                                            errorBuilder:
                                                (context, error, stackTrace) {
                                              return const Icon(
                                                  Icons.image_not_supported);
                                            },
                                          )
                                        : const Icon(Icons.image_not_supported,
                                            color: Colors.grey),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
