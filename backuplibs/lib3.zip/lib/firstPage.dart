import 'package:flutter/material.dart';

class Firstpage extends StatefulWidget {
  const Firstpage({super.key});

  @override
  State<Firstpage> createState() => _FirstpageState();
}

class _FirstpageState extends State<Firstpage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 250,
            width: double.infinity,
            // decoration: const BoxDecoration(
            //   image: DecorationImage(
            //     opacity: .8,
            //     image: AssetImage("assets/images/icon.png"),
            //   ),
            // ),
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "SAOIRSE",
                    style: TextStyle(
                        fontFamily: 'font1',
                        fontSize: 60,
                        letterSpacing: 5,
                        color:Color(0xFF223043),
                        shadows: [
                          Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 2.0,
                            color: Color(0xFF385B7B),
                          ),
                          Shadow(
                            offset: Offset(2.0, 2.0),
                            blurRadius: 2.0,
                            color: Color(0xFF385B7B),
                          ),
                        ]),
                  ),
                  Text(
                    "IT SOLUTIONS LLP",
                    style: TextStyle(
                        fontFamily: 'font1',
                        letterSpacing: 3,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF223043),
                        shadows: [
                          Shadow(
                            offset: Offset(.5, .5),
                            blurRadius: 2.0,
                            color: Color(0xFF385B7B),
                          ),
                          Shadow(
                            offset: Offset(.5, .5),
                            blurRadius: 2.0,
                            color: Color(0xFF385B7B),
                          ),
                        ]
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
            // margin: const EdgeInsets.symmetric(horizontal: 20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(25),
                topRight: Radius.circular(25),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // const Divider(
                //   color: Colors.grey,
                // ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  'What is EPI ?',
                  style: TextStyle(
                    letterSpacing: 2,
                    wordSpacing: 3,
                    fontFamily: "font",
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF223043),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                IntrinsicHeight(
                  child: Row(
                    children: [
                      const VerticalDivider(
                        color: Color(0xFF223043),
                        thickness: 2,
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Container(
                        height: MediaQuery.of(context).size.height * .125,
                        width: MediaQuery.of(context).size.width * .79,
                        child: const Text(
                          'Easy Purchase Investment is an innovative savings and shopping plan that allows you to invest small amounts daily or weekly. Accumulate funds to purchase items like iPhones and more while enjoying discounts and rewards!',
                          style: TextStyle(
                              letterSpacing: 1,
                              overflow: TextOverflow.clip,
                              fontSize: 12,
                              color: Colors.black87,
                              fontStyle: FontStyle.italic),
                        ),
                      ),
                    ],
                  ),
                ),
                // const Padding(
                //   padding: EdgeInsets.only(left: 15),
                //   child: Text(
                //     'Easy Purchase Investment is an innovative savings and shopping plan that allows you to invest small amounts daily or weekly. Accumulate funds to purchase items like iPhones and more while enjoying discounts and rewards!',
                //     style: TextStyle(
                //         letterSpacing: 1,
                //         overflow: TextOverflow.clip,
                //         fontSize: 12,
                //         color: Colors.black87,
                //         fontStyle: FontStyle.italic),
                //   ),
                // ),
                const SizedBox(
                  height: 10,
                ),

                Image.asset(
                  "assets/image/1.jpeg",
                  scale: 2,
                ),
                // const SizedBox(
                //   height: 30,
                // ),
                // const Divider(
                //   color: Colors.grey,
                // ),

                const Text(
                  'Features',
                  style: TextStyle(
                    letterSpacing: 1,
                    wordSpacing: 2,
                    fontFamily: "font",
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color:  Color(0xFF223043),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: "• ",
                              style:
                                  TextStyle(color:  Color(0xFF223043), fontSize: 15),
                            ),
                            TextSpan(
                              text: 'Invest small amounts daily/weekly',
                              style: TextStyle(
                                  letterSpacing: 1,
                                  color: Colors.black87,
                                  fontSize: 12,
                                  fontStyle: FontStyle.italic),
                            ),
                          ],
                        ),
                      ),
                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: "• ",
                              style:
                                  TextStyle(color:  Color(0xFF223043), fontSize: 15),
                            ),
                            TextSpan(
                              text: 'Get discounts on market rates.',
                              style: TextStyle(
                                  letterSpacing: 1,
                                  color: Colors.black87,
                                  fontSize: 12,
                                  fontStyle: FontStyle.italic),
                            ),
                          ],
                        ),
                      ),
                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: "• ",
                              style:
                                  TextStyle(color: Color(0xFF223043), fontSize: 15),
                            ),
                            TextSpan(
                              text:
                                  'Participate in lucky draws for exciting prizes.',
                              style: TextStyle(
                                  letterSpacing: 1,
                                  color: Colors.black87,
                                  fontSize: 12,
                                  fontStyle: FontStyle.italic),
                            ),
                          ],
                        ),
                      ),
                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: "• ",
                              style:
                                  TextStyle(color:  Color(0xFF223043), fontSize: 15),
                            ),
                            TextSpan(
                              text: 'Refer friends and earn daily commissions.',
                              style: TextStyle(
                                  letterSpacing: 1,
                                  color: Colors.black87,
                                  fontSize: 12,
                                  fontStyle: FontStyle.italic),
                            ),
                          ],
                        ),
                      ),
                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: "• ",
                              style:
                                  TextStyle(color:  Color(0xFF223043), fontSize: 15),
                            ),
                            TextSpan(
                              text:
                                  'Flexible and user-friendly investment process..',
                              style: TextStyle(
                                  letterSpacing: 1,
                                  color: Colors.black87,
                                  fontSize: 12,
                                  fontStyle: FontStyle.italic),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                // const Divider(
                //   color: Colors.grey,
                // ),
                const SizedBox(
                  height: 10,
                ),
                Image.asset(
                  "assets/image/2.jpeg",
                  scale: 2,
                ),
                const SizedBox(
                  height: 10,
                ),
                const Divider(
                  color: Colors.grey,
                ),
                const SizedBox(
                  height: 20,
                ),
                const Text(
                  "Products",
                  style: TextStyle(
                    letterSpacing: 1,
                    wordSpacing: 2,
                    fontFamily: "font",
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color:  Color(0xFF223043),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                SizedBox(
                  width: double.infinity,
                  height: 305,
                  child: Row(
                    children: [
                      Expanded(
                        child: Card(
                          color: Colors.white,
                          child: Column(
                            children: [
                              Image.asset("assets/image/watch.jpeg"),
                              const ListTile(
                                title: Text(
                                  "Obaku Watch",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12),
                                ),
                                subtitle: Text(
                                  "Elegant rose gold-tone chronograph with a blue dial and mesh strap for timeless sophistication and style.",
                                  style: TextStyle(letterSpacing: 1,
                                      color: Colors.black87,
                                      fontSize: 11,
                                      fontStyle: FontStyle.italic),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: Card(
                          color: Colors.white,
                          child: Column(
                            children: [
                              Image.asset("assets/image/lap.jpeg"),
                              const ListTile(
                                title: Text(
                                  "HP 15 Lap",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12),
                                ),
                                subtitle: Text(
                                  "A sleek design, 15.6-inch display, powerful performance, and long battery life for everyday computing.",
                                  style: TextStyle(letterSpacing: 1,
                                      color: Colors.black87,
                                      fontSize: 11,
                                      fontStyle: FontStyle.italic),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10,),
                SizedBox(
                  width: double.infinity,
                  height: 305,
                  child: Row(
                    children: [
                      Expanded(
                        child: Card(
                          color: Colors.white,
                          child: Column(
                            children: [
                              Image.asset("assets/image/phone.jpeg"),
                              const ListTile(
                                title: Text(
                                  "IPhone 12Pro",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12),
                                ),
                                subtitle: Text(
                                  "Super Retina XDR display,A14 Bionic chip,triple-camera system,and 5G support for exceptional performance and style.",
                                  style: TextStyle(letterSpacing: 1,
                                      overflow: TextOverflow.clip,
                                      color: Colors.black87,
                                      fontSize: 11,
                                      fontStyle: FontStyle.italic),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: Card(
                          color: Colors.white,
                          child: Column(
                            children: [
                              Image.asset("assets/image/speaker.jpeg"),
                              const ListTile(
                                title: Text(
                                  "JBL Bluetooth\nSpeaker",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12),
                                ),
                                subtitle: Text(
                                  "BL Flip 3 Bluetooth Speaker: waterproof, rich bass, wireless, 10-hour battery life.",
                                  style: TextStyle(letterSpacing: 1,
                                      color: Colors.black87,
                                      fontSize: 11,
                                      fontStyle: FontStyle.italic),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.end,
                //   children: [
                //     TextButton(
                //       onPressed: () {
                //         // Navigator.push(
                //         //     context,
                //         //     MaterialPageRoute(
                //         //         builder: (context) => const Homepage()));
                //       },
                //       child: const Text(
                //         "More >>",
                //         style: TextStyle(color: Colors.grey),
                //       ),
                //     ),
                //   ],
                // )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
