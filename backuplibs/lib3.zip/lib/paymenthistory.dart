import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PaymentHistoryPage extends StatelessWidget {
  final String userId;

  const PaymentHistoryPage({Key? key, required this.userId}) : super(key: key);

  Future<List<dynamic>> fetchPaymentHistory() async {
    const String url = 'http://13.60.166.65/payment_history.php';

    try {
      final response = await http.post(Uri.parse(url), body: {
        'action': 'view',
        'user_id': userId,
      });

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['payment_history'];
      } else {
        throw Exception("Failed to fetch payment history.");
      }
    } catch (e) {
      throw Exception("PLEASE CHECK YOUR INTERNET CONNECTION");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title:  Text("Payment History",style: TextStyle(fontFamily: "font"),)),
      body: FutureBuilder<List<dynamic>>(
        future: fetchPaymentHistory(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(
                child: Text(
              "${snapshot.error}",
              style: TextStyle(fontFamily: "font"),
            ));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
                child: Text(
              "No payment History available.",
              style: TextStyle(fontFamily: "font"),
            ));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final payment = snapshot.data![index];
                return Card(
                  margin: const EdgeInsets.all(8.0),
                  child: ListTile(
                    title: Text("Product ID: ${payment['product_id']}"),
                    subtitle: Text(
                      "Paid: ₹${payment['payment_amount']}\nBalance: ₹${payment['balance_amount']}",
                    ),
                    trailing: Text(payment['payment_date']),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
