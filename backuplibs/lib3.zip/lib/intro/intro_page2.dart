import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class intro_page2 extends StatefulWidget {
  const intro_page2({super.key});

  @override
  State<intro_page2> createState() => _intro_page2State();
}

class _intro_page2State extends State<intro_page2> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          const SizedBox(
            height: 250,
          ),
          SizedBox(
              height: 250,
              width: 300,
              child: Lottie.asset("assets/anim/intro2.json")),
          const SizedBox(
            height: 50,
          ),
          Text(
            "In Safe Hands",
            style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 20,
                fontWeight: FontWeight.bold),
          )
        ],
      ),
    );
  }
}
