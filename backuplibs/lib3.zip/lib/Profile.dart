import 'dart:convert';
import 'package:epi/Edit_profile.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late String userId;
  Map<String, dynamic> profileData = {}; // Holds user profile data

  @override
  void initState() {
    super.initState();
    _loadUserId();
  }

  // Load user ID from SharedPreferences
  Future<void> _loadUserId() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getString('id') ?? ''; // Retrieve the user ID
    });

    if (userId.isNotEmpty) {
      _fetchProfileData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("User ID not found. Please log in again.")),
      );
    }
  }

  // Fetch the profile data from the backend
  Future<void> _fetchProfileData() async {
    const String url =
        'http://13.60.166.65/profile.php'; // The backend API endpoint

    try {
      final response = await http.post(
        Uri.parse(url),
        body: {'user_id': userId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status_code'] == 200) {
          setState(() {
            profileData =
            data['data'][0]; // Get first user (should only be one)
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['msg'])),
          );
        }
      } else {
        throw Exception('Failed to fetch profile data.');
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error fetching profile data.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Handle null values by replacing them with empty strings or default values
    final username = profileData['Username'] ?? 'N/A';
    final email = profileData['Email'] ?? 'N/A';
    final referredBy = profileData['Referd_by'] ?? 'N/A';
    final referralCode = profileData['new_referal_code'] ?? 'N/A';

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "PROFILE",
          style: TextStyle(
            color: Colors.black,
            letterSpacing: 5,
            fontWeight: FontWeight.bold,
            fontFamily: "font",
          ),
        ),
        ///////////////////////////////////
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>ProfileEdit()));
            },
            icon: const Icon(Icons.edit, color: Colors.black),
          ),
        ],
      ),
      body: profileData.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding:
        const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 30),

            const CircleAvatar(
              radius: 45,
              backgroundColor: Colors.black,
              child: Icon(
                Icons.person,
                size: 60,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 50),
            // const Divider(color: Colors.black),

            ProfileInfoRow(
                icon: Icons.person, label: "Name :", value: '$username'),
            const Divider(color: Colors.black),

            ProfileInfoRow(
                icon: Icons.email, label: "Email :", value: '$email'),
            const Divider(color: Colors.black),

            ProfileInfoRow(
                icon: Icons.code,
                label: "Referred By :",
                value: '$referredBy'),
            const Divider(color: Colors.black),

            ProfileInfoRow(
                icon: Icons.code,
                label: "Referral  Code :",
                value: '$referralCode'),

            const Divider(color: Colors.black),
          ],
        ),
      ),
    );
  }
}

class ProfileInfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  ProfileInfoRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
      child: Row(
        children: [
          Icon(
            icon,
            color: Colors.black54,
            size: 35,
          ),
          const SizedBox(width: 15),
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const Spacer(),
          Text(value,
              style: const TextStyle(
                  color: Colors.black54, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}