import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:epi/payscheme.dart';
import 'package:neumorphic_button/neumorphic_button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class HundredEpicalc extends StatefulWidget {
  final String productId;
  final double price;
  final String? image;
  final String? name;

  const HundredEpicalc(
      {Key? key,
      required this.productId,
      required this.price,
      this.image,
      this.name})
      : super(key: key);

  @override
  State<HundredEpicalc> createState() => _HundredEpicalcState();
}

class _HundredEpicalcState extends State<HundredEpicalc> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _productIdController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  double _totalAmount = 0.0;
  double _dailyPayment = 100.0;
  int _daysRequired = 0;
  int _years = 0;
  int _months = 0;
  int _remainingDays = 0;
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now();
  bool termsAccepted = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _productIdController.text = widget.productId;
    _amountController.text = widget.price.toString();
  }

  void _calculateEPI() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _totalAmount = double.parse(_amountController.text);
        _daysRequired = (_totalAmount / _dailyPayment).ceil();

        // Calculate years, months, and days
        _years = _daysRequired ~/ 365;
        int totalMonths = (_daysRequired % 365) ~/ 30;
        _months = totalMonths;
        _remainingDays = (_daysRequired % 365) % 30;

        _startDate = DateTime.now();
        _endDate = _startDate.add(Duration(days: _daysRequired));
      });
    }
  }

  void _proceedToNextPage() async {
    try {
      await _saveResults();

      final userId = await _uploadData();
      if (userId != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => SchemeAndPayment(userId: userId)),
        );
      }
    } catch (e) {
      print("Error during navigation: $e");
      _showErrorDialog(
          "An error occurred while processing your request. Please try again.");
    }
  }

  Future<void> _saveResults() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('total_amount', _totalAmount);
    await prefs.setDouble('daily_payment', _dailyPayment);
    await prefs.setInt('days_required', _daysRequired);
    await prefs.setString('start_date', _startDate.toIso8601String());
    await prefs.setString('end_date', _endDate.toIso8601String());
  }

  Future<String?> _uploadData() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('id') ?? ''; // Retrieve user ID
    final productId = _productIdController.text.trim();

    try {
      final response = await http.post(
        Uri.parse('http://13.60.166.65/submit_epi.php'),
        // Replace with your EC2 instance IP
        body: {
          'product_id': productId,
          'total_amount': _totalAmount.toString(),
          'daily_payment': _dailyPayment.toString(),
          'days_required': _daysRequired.toString(),
          'start_date': _startDate.toIso8601String(),
          'end_date': _endDate.toIso8601String(),
          'user_id': userId,
        },
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);

        // Handle the updated response structure
        if (jsonResponse['status_code'] == 200 &&
            jsonResponse['status'] == "Success") {
          print('Message: ${jsonResponse['message']}');
          return userId; // Return the user ID directly since it's already stored
        } else {
          print('Unexpected response format: $jsonResponse');
          _showErrorDialog(jsonResponse['message'] ??
              "An error occurred. Please try again.");
        }
      } else {
        print('Server error: ${response.statusCode}');
        _showErrorDialog("Server error occurred. Please try again later.");
      }
    } catch (e) {
      print('Error during data upload: $e');
      _showErrorDialog(
          "An error occurred. Please check your connection and try again.");
    }

    return null;
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white,
        title: const Text("Make Your Plan"),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 20.0, right: 20, top: 40),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Divider(),
                Container(
                  height: 120,
                  width: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: 120,
                        width: 120,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          image: DecorationImage(
                            image: NetworkImage("${widget.image}"),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const Spacer(),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * .5,
                        child: Text(
                          '${widget.name}',
                          style: const TextStyle(
                              fontFamily: "font", overflow: TextOverflow.fade),
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                const SizedBox(
                  height: 30,
                ),
                TextFormField(
                  enabled: false,
                  controller: _productIdController,
                  decoration: const InputDecoration(
                    disabledBorder: OutlineInputBorder(),
                    floatingLabelBehavior: FloatingLabelBehavior.always,
                    labelText: 'Product ID',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the product ID';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                TextFormField(
                  enabled: false,
                  controller: _amountController,
                  decoration: const InputDecoration(
                    disabledBorder: OutlineInputBorder(),
                    labelText: 'Total Amount',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the total amount';
                    }
                    if (double.tryParse(value) == null ||
                        double.parse(value) <= 0) {
                      return 'Please enter a valid amount';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                const Text(
                  "100rs Daily:",
                  style: TextStyle(
                      fontWeight: FontWeight.bold, fontFamily: "font"),
                ),
                const SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    NeumorphicButton(
                      onTap: _calculateEPI,
                      bottomRightShadowBlurRadius: 15,
                      bottomRightShadowSpreadRadius: 1,
                      borderWidth: 5,
                      backgroundColor: const Color(0xFF84B5C2),
                      topLeftShadowBlurRadius: 15,
                      topLeftShadowSpreadRadius: 1,
                      topLeftShadowColor: Colors.white,
                      bottomRightShadowColor: Colors.grey.shade500,
                      height: 40,
                      width: MediaQuery.of(context).size.width * 0.4,
                      padding: EdgeInsets.zero,
                      margin: const EdgeInsets.only(right: 5, bottom: 5),
                      bottomRightOffset: const Offset(4, 4),
                      topLeftOffset: const Offset(-4, -4),
                      child: const Center(
                        child: Text(
                          'Calculate',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                if (_daysRequired > 0)
                  Center(
                    child: Card(
                      color: Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Days Required: $_daysRequired days"),
                            if (_years > 0)
                              Text(
                                  "Equivalent Time: $_years years, $_months months, and $_remainingDays days"),
                            if (_years == 0)
                              Text(
                                  "Equivalent Time: $_months months and $_remainingDays days"),
                            Text(
                                "Start Date: ${DateFormat('dd MMM yyyy').format(_startDate)}"),
                            Text(
                                "End Date: ${DateFormat('dd MMM yyyy').format(_endDate)}"),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF84B5C2),
                                  ),
                                  onPressed: _showTermsAndConditionsPopup,
                                  child: const Text(
                                    "Continue",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showTermsAndConditionsPopup() {
    bool showMoreDetails = false;
    bool termsAccepted = false;
    bool acknowledgeTerms = false;
    bool confirmParticipation = false;
    bool understandLegality = false;
    bool acknowledgeLegalRecourse = false;
    bool agreeToTerms = false;
    bool doNotAgree = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              title: const Text(
                "Terms and Conditions",
                style: TextStyle(fontFamily: "font", fontSize: 25),
              ),
              content: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "By creating an account, you agree to our Terms and Conditions.",
                      style: TextStyle(
                          fontSize: 14,
                          color: Colors.black,
                          overflow: TextOverflow.clip),
                    ),
                    if (showMoreDetails)
                      const Padding(
                        padding: EdgeInsets.only(top: 20.0),
                        child: Text(
                          "[Full Terms and Conditions and Privacy Policy here]",
                          style: TextStyle(fontSize: 12, color: Colors.black),
                        ),
                      ),
                    const SizedBox(
                      height: 5,
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          showMoreDetails = !showMoreDetails;
                        });
                      },
                      child: Text(
                        showMoreDetails
                            ? "Show Less Details"
                            : "Read Full Details",
                        style: const TextStyle(color: Colors.deepPurpleAccent),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Checkbox(
                          value: acknowledgeTerms,
                          onChanged: (value) {
                            setState(() {
                              acknowledgeTerms = value!;
                            });
                          },
                        ),
                        const Expanded(
                          child: Text(
                              "I acknowledge and agree to the terms and conditions of the Investment and Product Purchase Agreement (Bond) as outlined above."),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Checkbox(
                          value: confirmParticipation,
                          onChanged: (value) {
                            setState(() {
                              confirmParticipation = value!;
                            });
                          },
                        ),
                        const Expanded(
                          child: Text(
                              "I confirm that I am participating voluntarily and agree to the deductions from my commission if I choose not to purchase the product."),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Checkbox(
                          value: understandLegality,
                          onChanged: (value) {
                            setState(() {
                              understandLegality = value!;
                            });
                          },
                        ),
                        const Expanded(
                          child: Text(
                              "I understand that this Agreement is legally binding and governed by the laws of India."),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Checkbox(
                          value: acknowledgeLegalRecourse,
                          onChanged: (value) {
                            setState(() {
                              acknowledgeLegalRecourse = value!;
                            });
                          },
                        ),
                        const Expanded(
                          child: Text(
                              "I acknowledge that I have the right to seek legal recourse against Saoirse IT Solutions LLP in case of failure to fulfill their obligations, within 7 to 10 days from the notification of failure."),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      "Digital Signature",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                        "By clicking the \"I Agree\" button below, I digitally sign this Agreement and confirm my understanding and acceptance of the terms outlined above."),
                    Row(
                      children: [
                        Checkbox(
                          value: agreeToTerms,
                          onChanged: (value) {
                            setState(() {
                              agreeToTerms = value!;
                            });
                          },
                        ),
                        const Expanded(
                          child: Text("I Agree"),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Checkbox(
                          value: doNotAgree,
                          onChanged: (value) {
                            setState(() {
                              doNotAgree = value!;
                            });
                          },
                        ),
                        const Expanded(
                          child: Text("I Do Not Agree"),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text(
                    "Cancel",
                    style: TextStyle(color: Colors.black, fontFamily: "font"),
                  ),
                ),
                ElevatedButton(
                  onPressed: agreeToTerms
                      ? () {
                          Navigator.of(context).pop();
                          _proceedToNextPage();
                        }
                      : null,
                  child: const Text(
                    "Agree",
                    style: TextStyle(color: Colors.black, fontFamily: "font"),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
