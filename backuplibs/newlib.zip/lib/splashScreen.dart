import 'dart:async';
import 'package:epi/Bottom_NavigationPage.dart';
import 'package:flutter/material.dart';
import 'package:epi/logIn.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shared_preferences/shared_preferences.dart';

class splashScreen extends StatefulWidget {
  const splashScreen({super.key});

  @override
  State<splashScreen> createState() => _splashScreenState();
}

class _splashScreenState extends State<splashScreen> {
  @override
  void initState() {
    super.initState();
    checkLoginStatus();
  }

  Future<void> checkLoginStatus() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('id'); // Check if user ID is stored

    // Navigate after 5 seconds
    await Future.delayed(const Duration(seconds: 3));
    if (userId == null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const logIn()),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) =>  const Bottom_NavigationPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Stack(
          children: [
            Container(
              alignment: const Alignment(0, 0),
              decoration: const BoxDecoration(
                  ),
              child: const Text(
                "EPI",
                style: TextStyle(
                    fontFamily: "font", letterSpacing: 30, fontSize: 100),
              ),
            ),
            const Align(
              alignment: Alignment(0, .2),
              child: Text(
                "Invest Small, Dream Big Own It!",
                style: TextStyle(
                  fontSize: 15,
                  fontFamily: "font",
                  color: Colors.grey,
                ),
              ),
            ),
          ],
        ).animate().fade(duration: const Duration(seconds: 2)),
      ),
    );
  }
}
