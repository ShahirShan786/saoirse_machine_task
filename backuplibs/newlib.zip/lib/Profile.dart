// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';

// import 'WISHLIST/wishlist_page.dart';
// import 'about.dart';
// import 'helpPage.dart';
// import 'logIn.dart';

// class ProfilePage extends StatefulWidget {
//   const ProfilePage({Key? key}) : super(key: key);

//   @override
//   _ProfilePageState createState() => _ProfilePageState();
// }

// class _ProfilePageState extends State<ProfilePage> {
//   late String userId;
//   Map<String, dynamic> profileData = {}; // Holds user profile data

//   @override
//   void initState() {
//     super.initState();
//     _loadUserId();
//   }

//   // Load user ID from SharedPreferences
//   Future<void> _loadUserId() async {
//     final prefs = await SharedPreferences.getInstance();
//     setState(() {
//       userId = prefs.getString('id') ?? ''; // Retrieve the user ID
//     });

//     if (userId.isNotEmpty) {
//       _fetchProfileData();
//     } else {
// ScaffoldMessenger.of(context).showSnackBar(
//   SnackBar(width: double.infinity,
//       content: Row(
//     children: [
//       const Text("User ID not found. Please log in again."),
//       const Spacer(),
//       TextButton(
//           onPressed: () {
//             logout(context);
//           },
//           child: const Text(
//             "LogIn",
//             style: TextStyle(fontFamily: "font", color: Colors.red),
//           ))
//     ],
//   )),
// );
//     }
//   }

//   Future<void> logout(BuildContext context) async {
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.remove('id'); // Clear the user ID
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (context) => const logIn()),
//     );
//   }

//   // Fetch the profile data from the backend
//   Future<void> _fetchProfileData() async {
//     const String url =
//         'http://16.171.26.118/profile.php'; // The backend API endpoint

//     try {
//       final response = await http.post(
//         Uri.parse(url),
//         body: {'user_id': userId},
//       );

//       if (response.statusCode == 200) {
//         final data = json.decode(response.body);
//         if (data['status_code'] == 200) {
//           setState(() {
//             profileData =
//                 data['data'][0]; // Get first user (should only be one)
//           });
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text(data['msg'])),
//           );
//         }
//       } else {
//         throw Exception('Failed to fetch profile data.');
//       }
//     } catch (e) {
//       print("Error: $e");
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text("Error fetching profile data.")),
//       );
//     }
//   }

// //////////////////////////////////////
//   Future<void> _saveProfileData(String name, String email) async {
//     const String url =
//         "http://16.171.26.118/edit_profile.php"; // The backend API endpoint for update

//     try {
//       final response = await http.post(
//         Uri.parse(url),
//         body: {
//           'user_id': userId,
//           'name': name,
//           'email': email,
//         },
//       );

//       if (response.statusCode == 200) {
//         final data = json.decode(response.body);
//         if (data['status_code'] == 200) {
//           setState(() {
//             profileData['Username'] = name;
//             profileData['Email'] = email;
//           });
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(content: Text("Profile updated successfully.")),
//           );
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text(data['msg'])),
//           );
//         }
//       } else {
//         throw Exception('Failed to update profile data.');
//       }
//     } catch (e) {
//       print("Error: $e");
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text("Error updating profile data.")),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     // Handle null values by replacing them with empty strings or default values
//     final username = profileData['Username'] ?? 'N/A';
//     final email = profileData['Email'] ?? 'N/A';
//     // final referredBy = profileData['Referd_by'] ?? 'N/A';
//     // final referralCode = profileData['new_referal_code'] ?? 'N/A';

//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: const Text(
//           "PROFILE",
//           style: TextStyle(
//             color: Colors.black,
//             letterSpacing: 5,
//             fontWeight: FontWeight.bold,
//             fontFamily: "font",
//           ),
//         ),
//       ),
//       body: profileData.isEmpty
//           ? const Center(child: CircularProgressIndicator())
//           : SingleChildScrollView(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   // ProfileInfoRow(
//                   //     icon: Icons.code,
//                   //     label: "Referred By :",
//                   //     value: '$referredBy'),
//                   // const Divider(color: Colors.black),
//                   //
//                   // ProfileInfoRow(
//                   //     icon: Icons.code,
//                   //     label: "Referral  Code :",
//                   //     value: '$referralCode'),
//                   Divider(
//                     color: Colors.grey.shade200,
//                   ),
//                   ListTile(
//                     leading: const CircleAvatar(
//                       radius: 30,
//                       backgroundColor: Color(0xFF223043),
//                       child: Icon(
//                         Icons.person,
//                         color: Colors.white,
//                       ),
//                     ),
//                     title: Text(
//                       "$username",
//                       style: const TextStyle(
//                         color: Colors.black,
//                         fontWeight: FontWeight.bold,
//                         fontFamily: "font",
//                       ),
//                     ),
//                     subtitle: Text(
//                       "$email",
//                       style: TextStyle(
//                         color: Colors.grey.shade500,
//                       ),
//                     ),
//                     trailing: IconButton(
//                       onPressed: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                             builder: (context) => EditProfilePage(
//                               name: username,
//                               email: email,
//                               onSave: (String newName, String newEmail) {
//                                 _saveProfileData(newName, newEmail);
//                               },
//                             ),
//                           ),
//                         );
//                       },
//                       icon: const Icon(Icons.edit, color: Colors.black),
//                     ),
//                   ),
//                   const SizedBox(
//                     height: 20,
//                   ),
//                   Container(
//                     alignment: Alignment.center,
//                     height: 60,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         top: BorderSide(color: Colors.grey.shade200),
//                       ),
//                     ),
//                     child: const ListTile(
//                       leading: Icon(
//                         Icons.account_balance_outlined,
//                         color: Color(0xFF223043),
//                       ),
//                       title: Text('Bank Account'),
//                       trailing: Icon(Icons.keyboard_arrow_right_outlined),
//                     ),
//                   ),
//                   Container(
//                     alignment: Alignment.center,
//                     height: 60,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         top: BorderSide(color: Colors.grey.shade200),
//                       ),
//                     ),
//                     child: const ListTile(
//                       leading: Icon(
//                         Icons.verified_outlined,
//                         color: Color(0xFF223043),
//                       ),
//                       title: Text('KYC Verify'),
//                       trailing: Icon(Icons.keyboard_arrow_right_outlined),
//                     ),
//                   ),
//                   Container(
//                     alignment: Alignment.center,
//                     height: 60,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         top: BorderSide(color: Colors.grey.shade200),
//                       ),
//                     ),
//                     child: ListTile(
//                       onTap: () {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => wishlisttab()));
//                       },
//                       leading: const Icon(
//                         Icons.favorite_border,
//                         color: Color(0xFF223043),
//                       ),
//                       title: const Text('Wishlist'),
//                       trailing: const Icon(Icons.keyboard_arrow_right_outlined),
//                     ),
//                   ),
//                   Container(
//                     alignment: Alignment.center,
//                     height: 60,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         top: BorderSide(color: Colors.grey.shade200),
//                       ),
//                     ),
//                     child: const ListTile(
//                       leading: Icon(
//                         Icons.shopping_cart_outlined,
//                         color: Color(0xFF223043),
//                       ),
//                       title: Text('Cart'),
//                       trailing: Icon(Icons.keyboard_arrow_right_outlined),
//                     ),
//                   ),
//                   Container(
//                     alignment: Alignment.center,
//                     height: 60,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         top: BorderSide(color: Colors.grey.shade200),
//                       ),
//                     ),
//                     child: ListTile(
//                       onTap: () {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => const about()));
//                       },
//                       leading: const Icon(
//                         Icons.info_outline,
//                         color: Color(0xFF223043),
//                       ),
//                       title: const Text('About'),
//                       trailing: const Icon(Icons.keyboard_arrow_right_outlined),
//                     ),
//                   ),

//                   Container(
//                     alignment: Alignment.center,
//                     height: 60,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         top: BorderSide(color: Colors.grey.shade200),
//                       ),
//                     ),
//                     child: ListTile(
//                       onTap: () {
//                         Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => const HelpPage()));
//                       },
//                       leading: const Icon(
//                         Icons.help_outline,
//                         color: Color(0xFF223043),
//                       ),
//                       title: const Text('Help'),
//                       trailing: const Icon(Icons.keyboard_arrow_right_outlined),
//                     ),
//                   ),
//                   Container(
//                     alignment: Alignment.center,
//                     height: 60,
//                     decoration: BoxDecoration(
//                       border: Border(
//                         bottom: BorderSide(color: Colors.grey.shade200),
//                         top: BorderSide(color: Colors.grey.shade200),
//                       ),
//                     ),
//                     child: ListTile(
//                       onTap: () {
//                         logout(context);
//                       },
//                       leading: const Icon(
//                         Icons.logout,
//                         color: Colors.red,
//                       ),
//                       title: const Text(
//                         'Log Out',
//                         style: TextStyle(color: Colors.red),
//                       ),
//                       trailing: const Icon(
//                         Icons.keyboard_arrow_right_outlined,
//                         color: Colors.red,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//     );
//   }
// }

// class EditProfilePage extends StatefulWidget {
//   final String name;
//   final String email;
//   final Function(String, String) onSave;

//   const EditProfilePage(
//       {Key? key, required this.name, required this.email, required this.onSave})
//       : super(key: key);

//   @override
//   _EditProfilePageState createState() => _EditProfilePageState();
// }

// class _EditProfilePageState extends State<EditProfilePage> {
//   late TextEditingController _nameController;
//   late TextEditingController _emailController;

//   @override
//   void initState() {
//     super.initState();
//     _nameController = TextEditingController(text: widget.name);
//     _emailController = TextEditingController(text: widget.email);
//   }

//   @override
//   void dispose() {
//     _nameController.dispose();
//     _emailController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         surfaceTintColor: Colors.transparent,
//         centerTitle: true,
//         title: const Text(
//           "Edit Profile",
//           style: TextStyle(
//             color: Colors.black,
//             letterSpacing: 5,
//             fontWeight: FontWeight.bold,
//             fontFamily: "font",
//           ),
//         ),
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.all(20.0),
//           child: Column(
//             children: [
//               SizedBox(
//                 height: MediaQuery.of(context).size.height * .08,
//               ),
//               const CircleAvatar(
//                 radius: 50,
//                 backgroundColor: Color(0xFF223043),
//                 child: Icon(
//                   Icons.person,
//                   color: Colors.white,
//                 ),
//               ),
//               SizedBox(
//                 height: MediaQuery.of(context).size.height * .08,
//               ),
//               TextField(
//                 controller: _nameController,
//                 decoration: InputDecoration(
//                     border: OutlineInputBorder(
//                         borderSide: BorderSide(color: Colors.grey.shade200)),
//                     focusedBorder: const OutlineInputBorder(
//                         borderSide: BorderSide(color: Colors.black)),
//                     labelText: "Name",
//                     floatingLabelBehavior: FloatingLabelBehavior.always),
//               ),
//               SizedBox(
//                 height: MediaQuery.of(context).size.height * .04,
//               ),
//               TextField(
//                 controller: _emailController,
//                 decoration: InputDecoration(
//                     border: OutlineInputBorder(
//                         borderSide: BorderSide(color: Colors.grey.shade200)),
//                     focusedBorder: const OutlineInputBorder(
//                         borderSide: BorderSide(color: Colors.black)),
//                     labelText: "Email",
//                     floatingLabelBehavior: FloatingLabelBehavior.always),
//               ),
//               SizedBox(
//                 height: MediaQuery.of(context).size.height * .08,
//               ),
//               ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   shape: const RoundedRectangleBorder(),
//                   fixedSize: const Size(600, 50),
//                   backgroundColor: const Color(0xFF223043),
//                 ),
//                 onPressed: () {
//                   widget.onSave(
//                     _nameController.text,
//                     _emailController.text,
//                   );
//                   Navigator.pop(context);
//                 },
//                 child: const Text(
//                   "Save",
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 20,
//                     letterSpacing: 3,
//                     fontFamily: "font",
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'WISHLIST/wishlist_page.dart';
import 'about.dart';
import 'bank_account.dart';
import 'helpPage.dart';
import 'logIn.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late String userId;
  Map<String, dynamic> profileData = {}; // Holds user profile data

  @override
  void initState() {
    super.initState();
    _loadUserId();
  }

  // Load user ID from SharedPreferences
  Future<void> _loadUserId() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getString('id') ?? ''; // Retrieve the user ID
    });

    if (userId.isNotEmpty) {
      _fetchProfileData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            width: double.infinity,
            content: Row(
              children: [
                const Text("User ID not found. Please log in again."),
                const Spacer(),
                TextButton(
                    onPressed: () {
                      logout(context);
                    },
                    child: const Text(
                      "LogIn",
                      style: TextStyle(fontFamily: "font", color: Colors.red),
                    ))
              ],
            )),
      );
    }
  }

  Future<void> logout(BuildContext context) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('id'); // Clear the user ID
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const logIn()),
    );
  }

  // Fetch the profile data from the backend
  Future<void> _fetchProfileData() async {
    const String url =
        'http://16.171.26.118/profile.php'; // The backend API endpoint
    try {
      final response = await http.post(
        Uri.parse(url),
        body: {'user_id': userId},
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status_code'] == 200) {
          setState(() {
            profileData =
                data['data'][0]; // Get first user (should only be one)
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['msg'])),
          );
        }
      } else {
        throw Exception('Failed to fetch profile data.');
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error fetching profile data.")),
      );
    }
  }

//////////////////////////////////////
  Future<void> _saveProfileData(String name, String email) async {
    const String url =
        "http://16.171.26.118/edit_profile.php"; // The backend API endpoint for update
    try {
      final response = await http.post(
        Uri.parse(url),
        body: {
          'user_id': userId,
          'name': name,
          'email': email,
        },
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status_code'] == 200) {
          setState(() {
            profileData['Username'] = name;
            profileData['Email'] = email;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Profile updated successfully.")),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['msg'])),
          );
        }
      } else {
        throw Exception('Failed to update profile data.');
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error updating profile data.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Handle null values by replacing them with empty strings or default values
    final username = profileData['Username'] ?? 'N/A';
    final email = profileData['Email'] ?? 'N/A';
    // final referredBy = profileData['Referd_by'] ?? 'N/A';
    // final referralCode = profileData['new_referal_code'] ?? 'N/A';

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "PROFILE",
          style: TextStyle(
            color: Colors.black,
            letterSpacing: 5,
            fontWeight: FontWeight.bold,
            fontFamily: "font",
          ),
        ),
      ),
      body: profileData.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Divider(
                    color: Colors.grey.shade200,
                  ),
                  ListTile(
                    leading: const CircleAvatar(
                      radius: 30,
                      backgroundColor: Color(0xFF223043),
                      child: Icon(
                        Icons.person,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      "$username",
                      style: const TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontFamily: "font",
                      ),
                    ),
                    subtitle: Text(
                      "$email",
                      style: TextStyle(
                        color: Colors.grey.shade500,
                      ),
                    ),
                    trailing: IconButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => EditProfilePage(
                              name: username,
                              email: email,
                              onSave: (String newName, String newEmail) {
                                _saveProfileData(newName, newEmail);
                              },
                            ),
                          ),
                        );
                      },
                      icon: const Icon(Icons.edit, color: Colors.black),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const BankAccountPage()));
                      },
                      leading: const Icon(
                        Icons.account_balance_outlined,
                        color: Color(0xFF223043),
                      ),
                      title: const Text('Bank Account'),
                      trailing: const Icon(Icons.keyboard_arrow_right_outlined),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: const ListTile(
                      leading: Icon(
                        Icons.verified_outlined,
                        color: Color(0xFF223043),
                      ),
                      title: Text('KYC Verify'),
                      trailing: Icon(Icons.keyboard_arrow_right_outlined),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => wishlisttab()));
                      },
                      leading: const Icon(
                        Icons.favorite_border,
                        color: Color(0xFF223043),
                      ),
                      title: const Text('Wishlist'),
                      trailing: const Icon(Icons.keyboard_arrow_right_outlined),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: const ListTile(
                      leading: Icon(
                        Icons.shopping_cart_outlined,
                        color: Color(0xFF223043),
                      ),
                      title: Text('Cart'),
                      trailing: Icon(Icons.keyboard_arrow_right_outlined),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const about()));
                      },
                      leading: const Icon(
                        Icons.info_outline,
                        color: Color(0xFF223043),
                      ),
                      title: const Text('About'),
                      trailing: const Icon(Icons.keyboard_arrow_right_outlined),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border(
                        top: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const HelpPage()));
                      },
                      leading: const Icon(
                        Icons.help_outline,
                        color: Color(0xFF223043),
                      ),
                      title: const Text('Help'),
                      trailing: const Icon(Icons.keyboard_arrow_right_outlined),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    height: 60,
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(color: Colors.grey.shade200),
                        top: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    child: ListTile(
                      onTap: () {
                        logout(context);
                      },
                      leading: const Icon(
                        Icons.logout,
                        color: Colors.red,
                      ),
                      title: const Text(
                        'Log Out',
                        style: TextStyle(color: Colors.red),
                      ),
                      trailing: const Icon(
                        Icons.keyboard_arrow_right_outlined,
                        color: Colors.red,
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  final String name;
  final String email;
  final Function(String, String) onSave;

  const EditProfilePage(
      {Key? key, required this.name, required this.email, required this.onSave})
      : super(key: key);
  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.name);
    _emailController = TextEditingController(text: widget.email);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        surfaceTintColor: Colors.transparent,
        centerTitle: true,
        title: const Text(
          "Edit Profile",
          style: TextStyle(
            color: Colors.black,
            letterSpacing: 5,
            fontWeight: FontWeight.bold,
            fontFamily: "font",
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * .12,
              ),
              const CircleAvatar(
                radius: 50,
                backgroundColor: Color(0xFF223043),
                child: Icon(
                  Icons.person,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * .08,
              ),
              TextField(
                controller: _nameController,
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey.shade200)),
                    focusedBorder: const OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black)),
                    labelText: "Name",
                    floatingLabelBehavior: FloatingLabelBehavior.always),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * .04,
              ),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey.shade200)),
                    focusedBorder: const OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black)),
                    labelText: "Email",
                    floatingLabelBehavior: FloatingLabelBehavior.always),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height * .08,
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shape: const RoundedRectangleBorder(),
                  fixedSize: const Size(600, 50),
                  backgroundColor: const Color(0xFF223043),
                ),
                onPressed: () {
                  widget.onSave(
                    _nameController.text,
                    _emailController.text,
                  );
                  Navigator.pop(context);
                },
                child: const Text(
                  "Save",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    letterSpacing: 3,
                    fontFamily: "font",
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
