import 'package:epi/HOME/HomePage.dart';
import 'package:epi/PRODUCT%20TAB/product_origin.dart';
import 'package:epi/payscheme.dart';
import 'package:epi/referalcode.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Profile.dart';
import 'logIn.dart';

class Bottom_NavigationPage extends StatefulWidget {
  const Bottom_NavigationPage({super.key});

  @override
  _Bottom_NavigationPageState createState() => _Bottom_NavigationPageState();
  // State<Bottom_NavigationPage> createState() => _Bottom_NavigationPageState();
}

class _Bottom_NavigationPageState extends State<Bottom_NavigationPage> {
  String? userId;
  int currentindex = 0;

  Future<void> logout(BuildContext context) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('id'); // Clear the user ID
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const logIn()),
    );
  }

  // Fetch userId on initialization
  @override
  void initState() {
    super.initState();
   _loadUserId();
  }

  Future<void> _loadUserId() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getString('id') ?? ''; // Retrieve the user ID
    });
  }

  List<Widget> screens() {
    return [
      const Homepage(),
      ProductOrigin(),
      SchemeAndPayment(userId: userId.toString()), // Pass userId here
      const ReferralCode(),
      const ProfilePage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: SizedBox(
        height: 70,
        child: BottomNavigationBar(
          backgroundColor: Colors.white,
          unselectedItemColor: Colors.grey,
          unselectedLabelStyle: const TextStyle(color: Colors.grey),
          selectedItemColor: const Color(0xFF223043),
          showUnselectedLabels: true,
          selectedFontSize: 12,
          currentIndex: currentindex,
          type: BottomNavigationBarType.fixed,
          // fixedColor: Colors.deepPurle,
          items: [
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/home.png",
                  scale: 20,
                  color: currentindex == 0 ? Colors.red : Colors.black,
                ),
                label: "Home"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/menu.png",
                  scale: 20,
                  color: currentindex == 1 ? Colors.red : Colors.black,
                ),
                label: "Products"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/copy.png",
                  scale: 20,
                  color: currentindex == 2 ? Colors.red : Colors.black,
                ),
                label: "Plans"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/connect.png",
                  scale: 20,
                  color: currentindex == 3 ? Colors.red : Colors.black,
                ),
                label: "Referral"),
            BottomNavigationBarItem(
                icon: Image.asset(
                  "assets/icon/user.png",
                  scale: 20,
                  color: currentindex == 4 ? Colors.red : Colors.black,
                ),
                label: "Profile"),
          ],

          onTap: (index) {
            setState(() {
              currentindex = index;
            });
          },
        ),
      ),
      body: SafeArea(child: screens()[currentindex]),
    );
  }
}
