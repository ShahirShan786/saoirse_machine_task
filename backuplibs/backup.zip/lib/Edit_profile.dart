import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ProfileEdit extends StatefulWidget {
  const ProfileEdit({Key? key}) : super(key: key);

  @override
  _ProfileEditState createState() => _ProfileEditState();
}

class _ProfileEditState extends State<ProfileEdit> {
  late String userId;
  Map<String, dynamic> profileData = {}; // Holds user profile data

  @override
  void initState() {
    super.initState();
    _loadUserId();
  }

  // Load user ID from SharedPreferences
  Future<void> _loadUserId() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userId = prefs.getString('id') ?? ''; // Retrieve the user ID
    });

    if (userId.isNotEmpty) {
      _fetchProfileData();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("User ID not found. Please log in again.")),
      );
    }
  }

  // Fetch the profile data from the backend
  Future<void> _fetchProfileData() async {
    const String url =
        'http://13.60.166.65/profile.php'; // The backend API endpoint

    try {
      final response = await http.post(
        Uri.parse(url),
        body: {'user_id': userId},
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status_code'] == 200) {
          setState(() {
            profileData =
            data['data'][0]; // Get first user (should only be one)
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['msg'])),
          );
        }
      } else {
        throw Exception('Failed to fetch profile data.');
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error fetching profile data.")),
      );
    }
  }
//////////////////////////////////////
  Future<void> _saveProfileData(String name, String email) async {
    const String url ="http://13.60.166.65/edit_profile.php"; // The backend API endpoint for update

    try {
      final response = await http.post(
        Uri.parse(url),
        body: {
          'user_id': userId,
          'name': name,
          'email': email,
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status_code'] == 200) {
          setState(() {
            profileData['Username'] = name;
            profileData['Email'] = email;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Profile updated successfully.")),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['msg'])),
          );
        }
      } else {
        throw Exception('Failed to update profile data.');
      }
    } catch (e) {
      print("Error: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error updating profile data.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Handle null values by replacing them with empty strings or default values
    final username = profileData['Username'] ?? 'N/A';
    final email = profileData['Email'] ?? 'N/A';
    final referredBy = profileData['Referd_by'] ?? 'N/A';
    final referralCode = profileData['new_referal_code'] ?? 'N/A';

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.grey.shade300,
        title: const Text(
          "PROFILE",
          style: TextStyle(
            color: Colors.black,
            letterSpacing: 5,
            fontWeight: FontWeight.bold,
            fontFamily: "font",
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditProfilePage(
                    name: username,
                    email: email,
                    onSave: (String newName, String newEmail) {
                      _saveProfileData(newName, newEmail);
                    },
                  ),
                ),
              );
            },
            icon: const Icon(Icons.edit, color: Colors.black),
          ),
        ],
      ),
      body: profileData.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding:
        const EdgeInsets.symmetric(horizontal: 20.0, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 30),
            const CircleAvatar(
              radius: 45,
              backgroundColor: Colors.black,
              child: Icon(
                Icons.person,
                size: 60,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 50),
            ProfileInfoRow(
                icon: Icons.person, label: "Name :", value: '$username'),
            const Divider(color: Colors.black),
            ProfileInfoRow(
                icon: Icons.email, label: "Email :", value: '$email'),
            const Divider(color: Colors.black),
            ProfileInfoRow(
                icon: Icons.code,
                label: "Reffered By :",
                value: '$referredBy'),
            const Divider(color: Colors.black),
            ProfileInfoRow(
                icon: Icons.code,
                label: "Reffered Code :",
                value: '$referralCode'),
            const Divider(color: Colors.black),
          ],
        ),
      ),
    );
  }
}

class ProfileInfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  ProfileInfoRow(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
      child: Row(
        children: [
          Icon(
            icon,
            color: Colors.black54,
            size: 35,
          ),
          const SizedBox(width: 15),
          Text(
            label,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const Spacer(),
          Text(value,
              style: const TextStyle(
                  color: Colors.black54, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  final String name;
  final String email;
  final Function(String, String) onSave;

  const EditProfilePage(
      {Key? key,
        required this.name,
        required this.email,
        required this.onSave})
      : super(key: key);

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late TextEditingController _nameController;
  late TextEditingController _emailController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.name);
    _emailController = TextEditingController(text: widget.email);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Edit Profile"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: "Email"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                widget.onSave(
                  _nameController.text,
                  _emailController.text,
                );
                Navigator.pop(context);
              },
              child: const Text("Save"),
            ),
          ],
        ),
      ),
    );
  }
}