// import 'package:epi/Profile.dart';
// import 'package:epi/helpPage.dart';
// import 'package:epi/payscheme.dart';
// import 'package:epi/vault_page.dart';
// import 'package:flutter/material.dart';
// import 'package:epi/logIn.dart';
// import 'package:epi/referalcode.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class drawer extends StatelessWidget {
//   const drawer({super.key});
//
//   Future<void> logout(BuildContext context) async {
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     await prefs.remove('id'); // Clear the user ID
//     Navigator.pushReplacement(
//       context,
//       MaterialPageRoute(builder: (context) => const logIn()),
//     );
//   }
//   Future<String?> _getUserId() async {
//     final SharedPreferences prefs = await SharedPreferences.getInstance();
//     return prefs.getString('id'); // Retrieve the user ID
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Drawer(
//       backgroundColor: Colors.white,
//       child: Column(
//         children: [
//            UserAccountsDrawerHeader(
//             decoration: BoxDecoration(color: Colors.grey.shade300),
//             accountName: const Text(""),
//             accountEmail: const Text(""),
//             currentAccountPicture: const CircleAvatar(backgroundColor: Colors.black54,
//               child: Icon(Icons.person,color: Colors.white,),
//             ),
//           ),
//           ListTile(
//             leading: const Icon(Icons.person),
//             title: const Text('Profile'),
//             onTap: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                     builder: (context) =>
//                         const ProfilePage()), // Navigate to ProfilePage
//               );
//             },
//           ),
//           // ListTile(
//           //   leading: const Icon(Icons.money_rounded),
//           //   title: const Text('Vault'),
//           //   onTap: () {
//           //     Navigator.push(
//           //       context,
//           //       MaterialPageRoute(
//           //           builder: (context) =>
//           //               const VaultPage(userId: 'userId',)), // Navigate to ProfilePage
//           //     );
//           //   },
//           // ),
//           ListTile(
//             leading: const Icon(Icons.money_rounded),
//             title: const Text('Vault'),
//             onTap: () async {
//               final userId = await _getUserId(); // Get the actual user ID from SharedPreferences
//               if (userId != null && userId.isNotEmpty) {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => VaultPage(userId: userId), // Pass the actual userId
//                   ),
//                 );
//               } else {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(
//                     content: Text("User ID not found. Please log in again."),
//                   ),
//                 );
//                 Navigator.pushReplacement(
//                   context,
//                   MaterialPageRoute(builder: (context) => const logIn()),
//                 );
//               }
//             },
//           ),
//
//           ListTile(
//             onTap: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(builder: (context) => const ReferralCode()),
//               );
//             },
//             leading: const Icon(Icons.code),
//             title: const Text('Referral Menu'),
//           ),
//           ListTile(
//             onTap: () async {
//               final userId = await _getUserId();
//               if (userId != null && userId.isNotEmpty) {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => SchemeAndPayment(userId: userId),
//                   ),
//                 );
//               } else {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(
//                     content: Text("User ID not found. Please log in again."),
//                   ),
//                 );
//                 Navigator.pushReplacement(
//                   context,
//                   MaterialPageRoute(builder: (context) => const logIn()),
//                 );
//               }
//             },
//             leading: const Icon(Icons.money),
//             title: const Text('EPI Plans'),
//           ),
//           // const ListTile(
//           //   leading: Icon(Icons.settings),
//           //   title: Text('Settings'),
//           // ),
//           // const ListTile(
//           //   leading: Icon(Icons.info),
//           //   title: Text('About'),
//           // ),
//           ListTile(
//             onTap: () {
//               Navigator.push(
//                   context, MaterialPageRoute(builder: (context) => const HelpPage()));
//             },
//             leading: const Icon(Icons.help),
//             title: const Text('Help'),
//           ),
//           const Divider(),
//           ListTile(
//             onTap: () {
//               logout(context);
//             },
//             leading: const Icon(Icons.logout),
//             title: const Text('Log Out'),
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'package:epi/Profile.dart';
import 'package:epi/about.dart';
import 'package:epi/helpPage.dart';
import 'package:epi/payscheme.dart';
import 'package:epi/vault_page.dart';
import 'package:flutter/material.dart';
import 'package:epi/logIn.dart';
import 'package:epi/referalcode.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DrawerMenu extends StatelessWidget {
  const DrawerMenu({super.key});

  Future<void> logout(BuildContext context) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('id'); // Clear the user ID
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const logIn()),
    );
  }

  Future<String?> _getUserId() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('id'); // Retrieve the user ID
    print('Retrieved userId: $userId'); // Debugging line
    return userId;
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: Column(
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(color: Colors.grey.shade300),
            accountName: const Text(""),
            accountEmail: const Text(""),
            currentAccountPicture: const CircleAvatar(
              backgroundColor: Colors.black54,
              child: Icon(
                Icons.person,
                color: Colors.white,
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('Profile'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ProfilePage()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.money_rounded),
            title: const Text('Vault'),
            onTap: () async {
              final userId = await _getUserId();
              if (userId != null && userId.isNotEmpty) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VaultPage(userId: userId),
                  ),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("User ID not found. Please log in again."),
                  ),
                );
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const logIn()),
                );
              }
            },
          ),
          ListTile(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ReferralCode()),
              );
            },
            leading: const Icon(Icons.code),
            title: const Text('Referral Menu'),
          ),
          ListTile(
            onTap: () async {
              final userId = await _getUserId();
              if (userId != null && userId.isNotEmpty) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SchemeAndPayment(userId: userId),
                  ),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("User ID not found. Please log in again."),
                  ),
                );
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const logIn()),
                );
              }
            },
            leading: const Icon(Icons.money),
            title: const Text('EPI Plans'),
          ),
          ListTile(
            onTap: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => const HelpPage()));
            },
            leading: const Icon(Icons.help),
            title: const Text('Help'),
          ),

          ListTile(
            leading: const Icon(Icons.info),
            title: const Text('About Us'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const about()),
              );
            },
          ),
          const Divider(),
          ListTile(
            onTap: () {
              logout(context);
            },
            leading: const Icon(Icons.logout),
            title: const Text('Log Out'),
          ),

        ],
      ),
    );
  }
}
