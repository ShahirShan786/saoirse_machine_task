import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class intro_page3 extends StatefulWidget {
  const intro_page3({super.key});

  @override
  State<intro_page3> createState() => _intro_page3State();
}

class _intro_page3State extends State<intro_page3> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          const SizedBox(
            height: 250,
          ),

          SizedBox(
              height: 250,
              width: 300,
              child: Lottie.asset("assets/anim/intro3.json")),
         
          const SizedBox(
            height: 50,
          ),
          const Text(
            "Get Start",
            style: const TextStyle(
              fontFamily: "font",
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          )
        ],
      ),
    );
  }
}
