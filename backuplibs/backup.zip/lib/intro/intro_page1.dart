import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class intro_page1 extends StatefulWidget {
  const intro_page1({super.key});

  @override
  State<intro_page1> createState() => _intro_page1State();
}

class _intro_page1State extends State<intro_page1> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          const SizedBox(
            height: 250,
          ),
          SizedBox(
              height: 250,
              width: 300,
              child: Lottie.asset("assets/anim/intro1.json")),
          const SizedBox(
            height: 50,
          ),
          Text(
            "Smart Invest",
            style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 20,
                fontWeight: FontWeight.bold),
          ),
          const SizedBox(
            height: 50,
          ),
        ],
      ),
    );
  }
}
