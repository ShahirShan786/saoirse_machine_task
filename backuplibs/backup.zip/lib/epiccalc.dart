import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:epi/payscheme.dart';
import 'package:neumorphic_button/neumorphic_button.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Epicalc extends StatefulWidget {
  final String productId;
  final double price;
  final String? image;
  final String? name;

  const Epicalc(
      {Key? key,
        required this.productId,
        required this.price,
        this.image,
        this.name})
      : super(key: key);

  @override
  State<Epicalc> createState() => _EpicalcState();
}

class _EpicalcState extends State<Epicalc> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _productIdController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  double _totalAmount = 0.0;
  double _dailyPayment = 200.0;
  List<double> _dailyPaymentOptions = [200, 500, 1000];
  int _daysRequired = 0;
  int _years = 0;
  int _months = 0;
  int _remainingDays = 0;
  DateTime _startDate = DateTime.now();
  DateTime _endDate = DateTime.now();
  bool termsAccepted = false;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _productIdController.text = widget.productId;
    _amountController.text = widget.price.toString();
  }

  void _calculateEPI() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _totalAmount = double.parse(_amountController.text);
        _daysRequired = (_totalAmount / _dailyPayment).ceil();

        // Calculate years, months, and days
        _years = _daysRequired ~/ 365;
        int totalMonths = (_daysRequired % 365) ~/ 30;
        _months = totalMonths;
        _remainingDays = (_daysRequired % 365) % 30;

        _startDate = DateTime.now();
        _endDate = _startDate.add(Duration(days: _daysRequired));
      });
    }
  }

  void _proceedToNextPage() async {
    try {
      await _saveResults();

      final userId = await _uploadData();
      if (userId != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => SchemeAndPayment(userId: userId)),
        );
      }
    } catch (e) {
      print("Error during navigation: $e");
      _showErrorDialog(
          "An error occurred while processing your request. Please try again.");
    }
  }

  Future<void> _saveResults() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('total_amount', _totalAmount);
    await prefs.setDouble('daily_payment', _dailyPayment);
    await prefs.setInt('days_required', _daysRequired);
    await prefs.setString('start_date', _startDate.toIso8601String());
    await prefs.setString('end_date', _endDate.toIso8601String());
  }

  Future<String?> _uploadData() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('id') ?? ''; // Retrieve user ID
    final productId = _productIdController.text.trim();

    try {
      final response = await http.post(
        Uri.parse('http://13.60.166.65/submit_epi.php'),
        // Replace with your EC2 instance IP
        body: {
          'product_id': productId,
          'total_amount': _totalAmount.toString(),
          'daily_payment': _dailyPayment.toString(),
          'days_required': _daysRequired.toString(),
          'start_date': _startDate.toIso8601String(),
          'end_date': _endDate.toIso8601String(),
          'user_id': userId,
        },
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);

        // Handle the updated response structure
        if (jsonResponse['status_code'] == 200 &&
            jsonResponse['status'] == "Success") {
          print('Message: ${jsonResponse['message']}');
          return userId; // Return the user ID directly since it's already stored
        } else {
          print('Unexpected response format: $jsonResponse');
          _showErrorDialog(jsonResponse['message'] ??
              "An error occurred. Please try again.");
        }
      } else {
        print('Server error: ${response.statusCode}');
        _showErrorDialog("Server error occurred. Please try again later.");
      }
    } catch (e) {
      print('Error during data upload: $e');
      _showErrorDialog(
          "An error occurred. Please check your connection and try again.");
    }

    return null;
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.white,
        title: const Text("Make Your Plan"),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 20.0, right: 20, top: 40),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Divider(),
                Container(
                  height: 120,
                  width: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: 120,
                        width: 120,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          image: DecorationImage(
                            image: NetworkImage("${widget.image}"),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const Spacer(),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * .5,
                        child: Text(
                          '${widget.name}',
                          style: const TextStyle(
                              fontFamily: "font", overflow: TextOverflow.fade),
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                const SizedBox(
                  height: 30,
                ),
                TextFormField(
                  controller: _productIdController,
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      floatingLabelBehavior: FloatingLabelBehavior.always,
                      labelText: 'Product ID',
                      labelStyle: TextStyle(color: Colors.grey)),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the product ID';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _amountController,
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Total Amount',
                      labelStyle: TextStyle(color: Colors.grey)),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the total amount';
                    }
                    if (double.tryParse(value) == null ||
                        double.parse(value) <= 0) {
                      return 'Please enter a valid amount';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                const Text(
                  "Select Daily Payment Option:",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      decoration: const BoxDecoration(
                          color: Color(0xFF84B5C2),
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      height: 40,
                      width: MediaQuery.of(context).size.width * 0.35,
                      child: Center(
                        child: DropdownButton<double>(
                          alignment: AlignmentDirectional.topStart,
                          dropdownColor: const Color(0xFF84B5C2),
                          value: _dailyPayment,
                          onChanged: (double? newValue) {
                            setState(() {
                              _dailyPayment = newValue!;
                            });
                          },
                          items: _dailyPaymentOptions
                              .map<DropdownMenuItem<double>>((double value) {
                            return DropdownMenuItem<double>(
                              value: value,
                              child: Text(
                                '₹${value.toStringAsFixed(2)}',
                                style: const TextStyle(color: Colors.white),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    NeumorphicButton(
                      onTap: _calculateEPI,
                      bottomRightShadowBlurRadius: 15,
                      bottomRightShadowSpreadRadius: 1,
                      borderWidth: 5,
                      backgroundColor: const Color(0xFF84B5C2),
                      topLeftShadowBlurRadius: 15,
                      topLeftShadowSpreadRadius: 1,
                      topLeftShadowColor: Colors.white,
                      bottomRightShadowColor: Colors.grey.shade500,
                      height: 40,
                      width: MediaQuery.of(context).size.width * 0.4,
                      padding: EdgeInsets.zero,
                      margin: const EdgeInsets.only(right: 5, bottom: 5),
                      bottomRightOffset: const Offset(4, 4),
                      topLeftOffset: const Offset(-4, -4),
                      child: const Center(
                        child: Text(
                          'Calculate',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                if (_daysRequired > 0) ...[
                  Text("Days Required: $_daysRequired days"),
                  if (_years > 0)
                    Text(
                        "Equivalent Time: $_years years, $_months months, and $_remainingDays days"),
                  if (_years == 0)
                    Text(
                        "Equivalent Time: $_months months and $_remainingDays days"),
                  Text(
                      "Start Date: ${DateFormat('dd MMM yyyy').format(_startDate)}"),
                  Text(
                      "End Date: ${DateFormat('dd MMM yyyy').format(_endDate)}"),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _showTermsAndConditionsPopup,
                    child: const Text("Continue"),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showTermsAndConditionsPopup() {
    bool showMoreDetails = false;
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              title: const Text(
                "Terms and Conditions",
                style: TextStyle(fontFamily: "font", fontSize: 25),
              ),
              content: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "By creating an account, you agree to our Terms and Conditions.",
                      style: TextStyle(
                          fontSize: 14,
                          color: Colors.black,
                          overflow: TextOverflow.clip),
                    ),
                    if (showMoreDetails)
                      const Padding(
                        padding: EdgeInsets.only(top: 20.0),
                        child: Text(
                          "Terms and Conditions for Elio e-Com APK\n\n"
                              "Effective Date: [Insert Date]\n\n"
                              "These Terms and Conditions (\"Agreement\") govern your download, installation, and use of the Elio e-Com APK (\"App\"). By accessing or using the App, you agree to be bound by this Agreement. If you do not agree to these terms, do not use the App.\n\n"
                              "1. Ownership\n\n"
                              "1.1. The App is developed and owned by Saoirse IT Solutions LLP.\n"
                              "1.2. All intellectual property rights related to the App, including logos, trademarks, and content, remain the exclusive property of Saoirse IT Solutions LLP.\n\n"
                              "2. License to Use\n\n"
                              "2.1. You are granted a limited, non-exclusive, non-transferable, and revocable license to use the App for personal purposes.\n"
                              "2.2. You may not:\n"
                              "    - Modify, copy, or distribute the App.\n"
                              "    - Use the App for commercial purposes without authorization.\n\n"
                              "3. Privacy and Data Protection\n\n"
                              "3.1. Your data will be handled in accordance with our Privacy Policy.\n"
                              "3.2. By using the App, you consent to the collection and use of your personal data as described in the Privacy Policy.\n\n"
                              "4. Security and Misuse\n\n"
                              "4.1. You agree not to misuse our services or attempt to compromise their security.\n"
                              "4.2. The company reserves the right to take action if security is breached or misuse is detected.\n\n"
                              "5. Modification of Terms\n\n"
                              "5.1. The company reserves the right to modify these terms at any time.\n"
                              "5.2. Any changes to the terms will be effective immediately upon posting the updated terms on the App or on the website.\n\n"
                              "6. Contact Information\n\n"
                              "6.1. If you have any questions regarding these Terms and Conditions, please contact us at support@eliotechno.com.\n\n"
                              "Privacy Policy for EPI APK\n\n"
                              "Effective Date: [Insert Date]\n\n"
                              "This Privacy Policy governs the collection, use, and sharing of personal information by the Easy Purchase Investment (EPI) APK, an initiative of Elio e-Com, a subsidiary of Saoirse IT Solutions LLP. By using the EPI APK (\"App\"), you agree to the practices described in this Privacy Policy. If you do not agree to this policy, please do not use the App.\n\n"
                              "1. Information We Collect\n\n"
                              "1.1. Personal Information\n"
                              "We collect personal information from users when they register, use the App, or engage with EPI services:\n"
                              "  - Full name\n"
                              "  - Email address\n"
                              "  - Phone number\n"
                              "  - Government-issued ID details (e.g., Aadhaar, PAN)\n"
                              "  - Residential address\n\n"
                              "1.2. Financial Information\n"
                              "Payment details such as UPI, credit/debit card, or bank account information for processing transactions related to the EPI scheme.\n\n"
                              "1.3. Usage Information\n"
                              "We may collect information about your interactions with the App, including:\n"
                              "  - Transaction history\n"
                              "  - App usage patterns and preferences\n"
                              "  - Referrals and commission tracking\n\n"
                              "1.4. Device Information\n"
                              "  - IP address\n"
                              "  - Device type, model, and operating system version\n"
                              "  - App version and crash logs\n\n"
                              "2. How We Use Your Information\n\n"
                              "We use the information collected for the following purposes:\n"
                              "  - To register and manage your EPI account.\n"
                              "  - To process your payments and investments for the EPI scheme.\n"
                              "  - To deliver products upon successful scheme completion.\n"
                              "  - To send you notifications about your investment progress, rewards, and any important updates related to the scheme.\n"
                              "  - To respond to your customer service inquiries.\n"
                              "  - To improve the functionality and user experience of the App.\n"
                              "  - To comply with legal, regulatory, and security obligations.\n\n"
                              "3. Sharing Your Information\n\n"
                              "3.1. With Service Providers\n"
                              "We may share your information with trusted third-party vendors and service providers to assist us in processing payments, managing products, or providing support services.\n\n"
                              "3.2. Legal and Regulatory Requirements\n"
                              "We may disclose your information when required by law, such as complying with a subpoena, court order, or other legal process, or when necessary to protect our rights and the safety of others.\n\n"
                              "3.3. Business Transfers\n"
                              "In the event of a merger, acquisition, or sale of assets, your personal information may be transferred to the new entity, and you will be notified via the App or email.\n\n"
                              "4. Data Security\n\n"
                              "4.1. We implement technical, administrative, and physical safeguards to protect your personal information.\n"
                              "4.2. While we take reasonable measures to protect your data, no method of electronic transmission or storage is entirely secure, and we cannot guarantee 100% security.\n\n"
                              "5. Retention of Information\n\n"
                              "5.1. We retain your personal information for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required by law.\n"
                              "5.2. After the retention period, your personal information will be securely deleted or anonymized.\n\n"
                              "6. User Rights\n\n"
                              "6.1. Access and Correction: You have the right to access and update your personal information through your EPI account.\n"
                              "6.2. Data Deletion: You may request the deletion of your account and personal data, subject to any legal or contractual obligations.\n"
                              "6.3. Opt-Out of Marketing: You can opt-out of receiving marketing communications at any time by changing your communication preferences within the App or contacting us directly.\n\n"
                              "7. Cookies and Tracking Technologies\n\n"
                              "7.1. We may use cookies, web beacons, and similar technologies to enhance your experience, analyze usage patterns, and improve the App's functionality.\n"
                              "7.2. You can manage your cookie preferences by adjusting your browser or device settings.\n\n"
                              "8. Third-Party Links\n\n"
                              "The App may contain links to third-party websites or services. This Privacy Policy applies only to the EPI APK, and we are not responsible for the privacy practices of third-party websites. We encourage you to review their privacy policies before providing any personal information.\n\n"
                              "9. Changes to This Privacy Policy\n\n"
                              "We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements.\n"
                              "Any changes will be posted within the App or communicated through email.\n"
                              "We encourage you to periodically review this policy to stay informed about how we are protecting your information.\n\n"
                              "10. Contact Us\n\n"
                              "For any questions or concerns regarding this Privacy Policy, or to exercise your rights regarding your personal data, please contact us at:\n"
                              "Email: [Insert Email Address]\n"
                              "Phone: [Insert Phone Number]\n"
                              "Website: [Insert Website URL]\n\n"
                              "By using the EPI APK, you consent to the practices described in this Privacy Policy. Please ensure you review this policy periodically for updates.",
                          style: TextStyle(fontSize: 12, color: Colors.black),
                        ),
                      ),
                    const SizedBox(
                      height: 5,
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          showMoreDetails = !showMoreDetails;
                        });
                      },
                      child: Text(
                        showMoreDetails
                            ? "Show Less Details"
                            : "Read Full Details",
                        style: const TextStyle(color: Colors.deepPurpleAccent),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Checkbox(
                          value: termsAccepted,
                          onChanged: (value) {
                            setState(() {
                              termsAccepted = value!;
                            });
                          },
                        ),
                        // ignore: prefer_const_constructors
                        SizedBox(width: 10),
                        const Expanded(
                          child: Text(
                            "I agree to the Terms and Conditions.",
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text(
                    "Cancel",
                    style: TextStyle(color: Colors.black, fontFamily: "font"),
                  ),
                ),
                ElevatedButton(
                  onPressed: termsAccepted
                      ? () {
                    Navigator.of(context).pop();
                    _proceedToNextPage();
                  }
                      : null,
                  child: const Text(
                    "Agree",
                    style: TextStyle(color: Colors.black, fontFamily: "font"),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
