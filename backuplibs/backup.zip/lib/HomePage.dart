import 'package:epi/firstPage.dart';
import 'package:epi/payscheme.dart';
import 'package:epi/product_fetch.dart';
import 'package:epi/product_origin.dart';
import 'package:epi/referalcode.dart';
import 'package:epi/widgets/drawer.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'helpPage.dart';
import 'logIn.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

int page = 0;

class _HomepageState extends State<Homepage> {
  dynamic userId;

  int currentindex = 0;

  Future<void> logout(BuildContext context) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('id'); // Clear the user ID
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const logIn()),
    );
  }

  Future<String?> _getUserId() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('id'); // Retrieve the user ID
  }

  // Fetch userId on initialization
  @override
  void initState() {
    super.initState();
    _initializeUserId();
  }

  Future<void> _initializeUserId() async {
    userId = await _getUserId();
    setState(() {}); // Rebuild widget once userId is fetched
  }

  List<Widget> screens() {
    return [
      const Firstpage(),
      ProductOrigin(),
      SchemeAndPayment(userId: userId), // Pass userId here
      const ReferralCode(),
      // const ProfilePage(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        unselectedItemColor: Colors.grey,
        unselectedLabelStyle: const TextStyle(color: Colors.grey),
        selectedItemColor: Color(0xFF84B5C2),
        showUnselectedLabels: true,
        currentIndex: currentindex,
        type: BottomNavigationBarType.fixed,
        // fixedColor: Colors.deepPurple,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.list), label: "Products"),
          BottomNavigationBarItem(
              icon: Icon(Icons.note_add_rounded), label: "Plans"),
          BottomNavigationBarItem(
              icon: Icon(Icons.paste_sharp), label: "Referral"),
          // BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
        onTap: (index) async {
          if (index == 1) {
            userId = await _getUserId();
          }
          setState(() {
            currentindex = index;
          });
        },
      ),
      appBar: AppBar(
        surfaceTintColor: Colors.transparent,
        centerTitle: true,
        backgroundColor: Colors.white,
        title: const Text(
          "EPI",
          style: TextStyle(
            color: Colors.black,
            letterSpacing: 8,
            fontWeight: FontWeight.bold,
            fontFamily: "font",
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const HelpPage()),
              );
            },
            icon: const Icon(Icons.help, color: Colors.black),
          ),
        ],
      ),
      body: screens()[currentindex],
      drawer: const DrawerMenu(),
    );
  }
}
