import 'package:epi/HomePage.dart';
import 'package:epi/referalcode.dart';
import 'package:flutter/material.dart';
import 'package:neumorphic_button/neumorphic_button.dart';

class Withdrawal extends StatefulWidget {
  String amount;
  Withdrawal({
    super.key,
    required this.amount,
  });

  @override
  State<Withdrawal> createState() => _WithdrawalState();
}

class _WithdrawalState extends State<Withdrawal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => Homepage()),
            );
          },
          icon: Icon(Icons.arrow_back),
        ),

        title: Text(
          'Withdrawal',
          style: TextStyle(color: Colors.black, fontFamily: "font"),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFormField(
              scrollPadding: EdgeInsets.zero,
              enabled: false,
              decoration:  InputDecoration(
                  prefixText: '${widget.amount}',
                  prefixStyle:
                  TextStyle(color: Colors.black, fontFamily: "font"),
                  disabledBorder: InputBorder.none,
                  label: Text(
                    "TOTAL AMOUNT",
                    style: TextStyle(color: Colors.grey),
                  ),
                  floatingLabelBehavior: FloatingLabelBehavior.always),
            ),
            SizedBox(height: 40),
            TextFormField(
              scrollPadding: EdgeInsets.zero,
              decoration: const InputDecoration(
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey)),
                  label: Text(
                    "WITHDROWAL AMOUNT",
                    style: TextStyle(color: Colors.grey),
                  ),
                  floatingLabelBehavior: FloatingLabelBehavior.always),
            ),
            SizedBox(height: 40),
            TextFormField(
              scrollPadding: EdgeInsets.zero,
              decoration: const InputDecoration(
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey)),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey)),
                  label: Text(
                    "ACCOUNT NO",
                    style: TextStyle(color: Colors.grey),
                  ),
                  floatingLabelBehavior: FloatingLabelBehavior.always),
            ),
            SizedBox(height: 60),
            NeumorphicButton(
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  builder: (BuildContext) {
                    return Container(
                      // color: const Color(0xFF84B5C2),
                      height: 200,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 25.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "AMOUNT",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: "font",
                                      fontSize: 25),
                                ),
                                Text("₹ 0",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: "font",
                                        fontSize: 25))
                              ],
                            ),
                            NeumorphicButton(
                              onTap: () {},
                              bottomRightShadowBlurRadius: 10,
                              bottomRightShadowSpreadRadius: 0,
                              backgroundColor: const Color(0xFF84B5C2),
                              topLeftShadowBlurRadius: 8,
                              topLeftShadowSpreadRadius: 0,
                              topLeftShadowColor: Colors.white,
                              bottomRightShadowColor: Colors.grey.shade500,
                              height: 50,
                              width: MediaQuery.of(context).size.width,
                              padding: EdgeInsets.zero,
                              margin:
                              const EdgeInsets.only(right: 5, bottom: 5),
                              bottomRightOffset: const Offset(4, 4),
                              topLeftOffset: const Offset(-4, -4),
                              child: const Center(
                                child: Text(
                                  'CONFIRM',
                                  style: TextStyle(fontSize: 18,
                                      color: Colors.white, fontFamily: "font"),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
              bottomRightShadowBlurRadius: 10,
              bottomRightShadowSpreadRadius: 0,
              backgroundColor: const Color(0xFF84B5C2),
              topLeftShadowBlurRadius: 8,
              topLeftShadowSpreadRadius: 0,
              topLeftShadowColor: Colors.white,
              bottomRightShadowColor: Colors.grey.shade500,
              height: 50,
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.zero,
              margin: const EdgeInsets.only(right: 5, bottom: 5),
              bottomRightOffset: const Offset(4, 4),
              topLeftOffset: const Offset(-4, -4),
              child: const Center(
                child: Text(
                  'REQUEST',
                  style: TextStyle(color: Colors.white, fontFamily: "font",fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}