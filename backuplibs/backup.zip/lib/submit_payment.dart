import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PaymentSubmissionPage extends StatefulWidget {
  final String userId; // Passed user ID
  final String productId; // Passed product ID
  final String dailyPayment; // Daily payment amount passed from the previous page

  const PaymentSubmissionPage({
    Key? key,
    required this.userId,
    required this.productId,
    required this.dailyPayment,
  }) : super(key: key);

  @override
  State<PaymentSubmissionPage> createState() => _PaymentSubmissionPageState();
}

class _PaymentSubmissionPageState extends State<PaymentSubmissionPage> {
  final TextEditingController _transactionIdController = TextEditingController();
  bool isSubmitting = false; // State for showing the progress indicator

  Future<void> _submitPayment() async {
    if (_transactionIdController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a transaction ID")),
      );
      return;
    }

    setState(() {
      isSubmitting = true;
    });

    try {
      final response = await http.post(
        Uri.parse("http://13.60.166.65/submit_payment.php"),
        body: {
          "User_id": widget.userId,
          "Product_id": widget.productId,
          "Transaction_id": _transactionIdController.text,
          "Daily_payment": widget.dailyPayment,
        },
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(response.body)),
        );
        Navigator.pop(context); // Return to the previous page
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to submit payment. Please try again.")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("An error occurred: $e")),
      );
    } finally {
      setState(() {
        isSubmitting = false;
      });
    }
  }

  // Function to get the appropriate QR code image path based on the daily payment option
  String _getQrCodeImage() {
    switch (widget.dailyPayment) {
      case "200":
        return "assets/images/QR.jpg"; // Replace with the actual path for ₹200
      case "500":
        return "assets/images/QR.jpg"; // Replace with the actual path for ₹500
      case "1000":
        return "assets/images/QR.jpg"; // Replace with the actual path for ₹1000
      default:
        return "assets/images/QR.jpg"; // Default QR code image
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(centerTitle: true,
        title: const Text("Submit Payment",style: TextStyle(fontFamily: "font"),),
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Display the QR code image
            Center(
              child: Image.asset(
                _getQrCodeImage(), // Fetch the appropriate QR code image based on payment option
                width: 200,
                height: 200,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              "Product ID: ${widget.productId}\nMake your daily payment of ₹${widget.dailyPayment}",
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _transactionIdController,
              decoration: InputDecoration(
                labelText: "Transaction ID",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: isSubmitting ? null : _submitPayment,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
              ),
              child: isSubmitting
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Submit Payment"),
            ),
          ],
        ),
      ),
    );
  }
}
