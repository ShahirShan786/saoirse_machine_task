import 'package:epi/100product_fetch.dart';
import 'package:epi/product_fetch.dart';
import 'package:flutter/material.dart';

class ProductOrigin extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          // title: Text("Easy Purchase Investment"),
          bottom: TabBar(
            tabs: [
              Tab(text: "Products"),
              Tab(text: "100 Rs Combo"),
            ],
          ),
          toolbarHeight: 1.0, // Reduced height
        ),
        body: TabBarView(
          children: [
            Operation(),
            hundredOperation(),
          ],
        ),
      ),
    );
  }
}
